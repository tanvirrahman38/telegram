import modules.client, modules.afoot, modules.selfdestruct, modules.details, modules.bombing, modules.translate, modules.wikipedia, modules.accountlimit, modules.covidinformation, modules.userhistory, modules.iptrace, modules.generatepassword, modules.removemessage, modules.goodmorning, modules.goodafternoon, modules.goodevening, modules.goodnight, modules.telegraph, modules.removealldp, modules.imageaction, modules.removeallmessages, modules.removemessagesforcefully, modules.ban, modules.kick, modules.banall, modules.kickall, modules.calculator, modules.whois, modules.hosthunter, modules.useraccountupdate, modules.texttospeech, modules.secretmessage, modules.phonenumbertrace, modules.restoremessage, modules.ping, modules.emailvalidator, modules.worldclock, modules.urlshortener, modules.qrcode, modules.usernamevalidation, modules.imagetopdf, modules.currencyinformation, modules.googlesearch, modules.webpagescreenshot, modules.zipcodeinformation, modules.tvshowinformation, modules.quotly, modules.dictionary, modules.generatedata, modules.carbon, modules.creditcardchecker, modules.speedtest, modules.weather, modules.updater, modules.groupadminlist, modules.autoreact, modules.informationgather, modules.restrictedcontent, modules.pmprotection, modules.awayfromkeyboard, modules.muslimprayertime, modules.macvendor, modules.phonebombing, modules.groupaction, modules.deletedaccount, modules.messagelogger, modules.unban, modules.sprunge

client = modules.client.client

with client as ridogram:
    ridogram.add_event_handler(modules.afoot.runafoot)

with client as ridogram:
    ridogram.add_event_handler(modules.selfdestruct.runsdmd)

with client as ridogram:
    ridogram.add_event_handler(modules.details.rundls)

with client as ridogram:
    ridogram.add_event_handler(modules.bombing.runbomb)

with client as ridogram:
    ridogram.add_event_handler(modules.translate.runtr)

with client as ridogram:
    ridogram.add_event_handler(modules.wikipedia.runwiki)

with client as ridogram:
    ridogram.add_event_handler(modules.accountlimit.runacsc)

with client as ridogram:
    ridogram.add_event_handler(modules.covidinformation.runcovid)

with client as ridogram:
    ridogram.add_event_handler(modules.userhistory.runuh)

with client as ridogram:
    ridogram.add_event_handler(modules.iptrace.runiptrace)

with client as ridogram:
    ridogram.add_event_handler(modules.generatepassword.rungpwd)

with client as ridogram:
    ridogram.add_event_handler(modules.removemessage.runrm)

with client as ridogram:
    ridogram.add_event_handler(modules.goodmorning.rungdm)

with client as ridogram:
    ridogram.add_event_handler(modules.goodafternoon.rungda)

with client as ridogram:
    ridogram.add_event_handler(modules.goodevening.rungde)

with client as ridogram:
    ridogram.add_event_handler(modules.goodnight.rungdn)

with client as ridogram:
    ridogram.add_event_handler(modules.telegraph.runtgu)

with client as ridogram:
    ridogram.add_event_handler(modules.removealldp.runrmdps)

with client as ridogram:
    ridogram.add_event_handler(modules.imageaction.runia)

with client as ridogram:
    ridogram.add_event_handler(modules.removeallmessages.runrma)

with client as ridogram:
    ridogram.add_event_handler(modules.removemessagesforcefully.runrmf)

with client as ridogram:
    ridogram.add_event_handler(modules.ban.runban)

with client as ridogram:
    ridogram.add_event_handler(modules.kick.runkick)

with client as ridogram:
    ridogram.add_event_handler(modules.banall.runfba)

with client as ridogram:
    ridogram.add_event_handler(modules.kickall.runfka)

with client as ridogram:
    ridogram.add_event_handler(modules.calculator.runccr)

with client as ridogram:
    ridogram.add_event_handler(modules.whois.runwhois)

with client as ridogram:
    ridogram.add_event_handler(modules.hosthunter.runhh)

with client as ridogram:
    ridogram.add_event_handler(modules.useraccountupdate.runuau)

with client as ridogram:
    ridogram.add_event_handler(modules.texttospeech.runtts)

with client as ridogram:
    ridogram.add_event_handler(modules.secretmessage.runb64)

with client as ridogram:
    ridogram.add_event_handler(modules.phonenumbertrace.runpntrace)

with client as ridogram:
    ridogram.add_event_handler(modules.restoremessage.runrgm)

with client as ridogram:
    ridogram.add_event_handler(modules.ping.runping)

with client as ridogram:
    ridogram.add_event_handler(modules.emailvalidator.runev)

with client as ridogram:
    ridogram.add_event_handler(modules.worldclock.runwc)

with client as ridogram:
    ridogram.add_event_handler(modules.urlshortener.runus)

with client as ridogram:
    ridogram.add_event_handler(modules.qrcode.runqrc)

with client as ridogram:
    ridogram.add_event_handler(modules.usernamevalidation.runuv)

with client as ridogram:
    ridogram.add_event_handler(modules.imagetopdf.runitp)

with client as ridogram:
    ridogram.add_event_handler(modules.currencyinformation.runci)

with client as ridogram:
    ridogram.add_event_handler(modules.googlesearch.rungs)

with client as ridogram:
    ridogram.add_event_handler(modules.webpagescreenshot.runwps)

with client as ridogram:
    ridogram.add_event_handler(modules.zipcodeinformation.runzci)

with client as ridogram:
    ridogram.add_event_handler(modules.tvshowinformation.runtvsi)

with client as ridogram:
    ridogram.add_event_handler(modules.quotly.runq)

with client as ridogram:
    ridogram.add_event_handler(modules.dictionary.runwm)

with client as ridogram:
    ridogram.add_event_handler(modules.generatedata.runfd)

with client as ridogram:
    ridogram.add_event_handler(modules.carbon.runtti)

with client as ridogram:
    ridogram.add_event_handler(modules.creditcardchecker.runn)

with client as ridogram:
    ridogram.add_event_handler(modules.speedtest.runst)

with client as ridogram:
    ridogram.add_event_handler(modules.weather.runwu)

with client as ridogram:
    ridogram.add_event_handler(modules.updater.runupdate)

with client as ridogram:
    ridogram.add_event_handler(modules.groupadminlist.runsa)

with client as ridogram:
    ridogram.add_event_handler(modules.autoreact.runar)

with client as ridogram:
    ridogram.add_event_handler(modules.informationgather.runig)

with client as ridogram:
    ridogram.add_event_handler(modules.restrictedcontent.rundrc)

with client as ridogram:
    ridogram.add_event_handler(modules.pmprotection.runpmgmon)

with client as ridogram:
    ridogram.add_event_handler(modules.pmprotection.runpmgmoff)

with client as ridogram:
    ridogram.add_event_handler(modules.pmprotection.runpmgmstatus)

with client as ridogram:
    ridogram.add_event_handler(modules.pmprotection.runap)

with client as ridogram:
    ridogram.add_event_handler(modules.pmprotection.rununap)

with client as ridogram:
    ridogram.add_event_handler(modules.pmprotection.runpmapprovedlist)

with client as ridogram:
    ridogram.add_event_handler(modules.pmprotection.runpmguard)

with client as ridogram:
    ridogram.add_event_handler(modules.awayfromkeyboard.runafkon)

with client as ridogram:
    ridogram.add_event_handler(modules.awayfromkeyboard.runafkoff)

with client as ridogram:
    ridogram.add_event_handler(modules.awayfromkeyboard.runafkstatus)

with client as ridogram:
    ridogram.add_event_handler(modules.awayfromkeyboard.runafk)

with client as ridogram:
    ridogram.add_event_handler(modules.awayfromkeyboard.runmcfafk)

with client as ridogram:
    ridogram.add_event_handler(modules.muslimprayertime.runmpt)

with client as ridogram:
    ridogram.add_event_handler(modules.macvendor.runmvi)

with client as ridogram:
    ridogram.add_event_handler(modules.phonebombing.runj)

with client as ridogram:
    ridogram.add_event_handler(modules.groupaction.runfag)

with client as ridogram:
    ridogram.add_event_handler(modules.groupaction.runfcid)

with client as ridogram:
    ridogram.add_event_handler(modules.deletedaccount.runsda)

with client as ridogram:
    ridogram.add_event_handler(modules.deletedaccount.runrda)

with client as ridogram:
    ridogram.add_event_handler(modules.messagelogger.runpmlog)

with client as ridogram:
    ridogram.add_event_handler(modules.messagelogger.runmentionlog)

with client as ridogram:
    ridogram.add_event_handler(modules.unban.rununban)

with client as ridogram:
    ridogram.add_event_handler(modules.details.runadls)

with client as ridogram:
    ridogram.add_event_handler(modules.restrictedcontent.runrts)

with client as ridogram:
    ridogram.add_event_handler(modules.sprunge.runcpis)

client.start()
print("Ridogram Started")
client.run_until_disconnected()